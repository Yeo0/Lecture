Requirements:

Python 2.4.1 and ArcGIS 9.2

Installing the Python Scripts:

Copy the python script (Spider_Create.py) to the ArcToolbox\Scripts folder located in the ArcGIS install directory. (ex. C:\Program Files\ArcGIS\ArcToolbox\Scripts)

Installing the Spider Tools Toolbox:

Step 1.	Copy the Spider Tools.tbx to the ArcToolbox Toolboxes folder located in the ArcGIS install directory. (ex. C:\Program Files\ArcGIS\ArcToolbox\Toolboxes)	

Step 2.	Open ArcCatalog and then expand the Toolboxes\System Toolboxes folder in the catalog tree.

Step 3.	Right click on the toolbox for the Spider Tools and left click �Add To ArcToolbox�.

Step 4.	Open the Spider Tools toolbox and right click on the script. Left click �properties� and then click the �Source� tab. Adjust the �Script File� path to reflect the location to which you copied the script file as described in �Installing the Python Script� above.


Point of Contact:

If you require additional information, please contact:

Tony Palmer
GIS Manager
U.S. Army Corps of Engineers, Tennessee-Tombigbee Waterway
3606 West Plymouth Road
Columbus, Mississippi 39701-9504

Phone: (662) 327-2142
Email: tony.palmer@sam.usace.army.mil
