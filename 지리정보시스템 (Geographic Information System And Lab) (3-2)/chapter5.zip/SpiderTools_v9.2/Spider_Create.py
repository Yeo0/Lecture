#Script Name: Spider_Create
#Script Label: Create Spider Diagrams
#
#Description:  Custom python script developed to create spider diagrams from points contained
#in one or two feature classes.  If using two feature classes, one feature class must contain
#the origins and the other must contain the destinations.
#
#Source Script File: Spider_Create.py
#Programming Language: Python 2.4
#ArcGIS Version: ArcGIS 9.2
#Author: Anthony Palmer, U.S. Army Corps of Engineers, Tennessee-Tombigbee Waterway
#Email: anthony.g.palmer@sam.usace.army.mil
#Date: 04/04/2007
#
#Parameters:
#
#           Display Name                         Data Type        Type      Direction  MultiValue  Dependency
#  argv[1]  Origin Point Feature Class           Feature Class    Required  Input      No
#  argv[2]  Select Subset of Origins             SQL Expression   Optional  Input      No          Origin Point Feature Class
#  argv[3]  Select Origin Key Field              Field            Required  Input      No          Origin Point Feature Class
#  argv[4]  Destination Point Feature Class      Feature Class    Required  Input      No
#  argv[2]  Select Subset of Destinations        SQL Expression   Optional  Input      No          Destination Point Feature Class
#  argv[6]  Select Destination Key Field         Field            Required  Input      No          Destination Point Feature Class
#  argv[7]  Output Polyline Feature Class        Feature Class    Required  Output     No
#----------------------------------------------------------------------------------------------------------------------
#
#import modules and create the geoprocessor object
#
import arcgisscripting, os, sys, string, math
gp = arcgisscripting.create()
#
# Get the input and output feature class names, key fields, and optional sql expressions
#
orgFC = sys.argv[1]    # input feature class
orgExp = sys.argv[2]   # expression identifying origins 
orgkey = sys.argv[3]   # origin key field
desFC = sys.argv[4]    # destination feature class
desExp = sys.argv[5]   # expression identifying destinations
deskey = sys.argv[6]   # destination key field
outFC = sys.argv[7]    # output polyline feature class
#
#Verify origin and destination features classes are points and determine their projection.
#
orgdesc = gp.Describe(orgFC)
desdesc = gp.Describe(desFC)
orgShapeField = orgdesc.ShapeFieldName
desShapeField = desdesc.ShapeFieldName
orgsr = orgdesc.SpatialReference
dessr = desdesc.SpatialReference
orgsrtype = str(orgsr.Type)
dessrtype = str(dessr.Type)
if orgdesc.ShapeType == "Point" and desdesc.ShapeType == "Point":
    if orgsrtype == "Unknown" or dessrtype == "Unknown":
        gp.AddError("Error:  Either the projection for the origins, destinations, or both is undefined. (Exiting Script)")
        sys.exit()
    elif orgsrtype != dessrtype:
        gp.AddError("Error:  The origin and destination feature classes must have the same projection. (Exiting Script)")
        sys.exit()
    else:
        pass
else:
    gp.AddError("Error:  Either the origins, destinations, or both are not point feature classes. (Exiting Script)")    
    sys.exit()
#
#Verify origin and destination key fields and identify field types
#
orgfields = gp.ListFields(orgFC)
orgfield = orgfields.Next()
desfields = gp.ListFields(desFC)
desfield = desfields.Next()
try:
    while orgfield:
        if orgfield.Name == orgkey:
            orgftype = orgfield.Type
            orgflength = orgfield.Length
            break
        else:
            pass
        orgfield = orgfields.Next()
    if orgftype == "String":
        orgntype = "Text"
        orgnlength = orgflength
    elif orgftype == "Integer":
        orgntype = "Long"
    elif orgftype == "SmallInteger":
        orgntype = "Short"
    else:
        gp.AddError("Origin Key field type is not a string, integer, or small integer. (Exiting Script).")
        sys.exit()
    del orgfields
    del orgfield
    while desfield:
        if desfield.Name == deskey:
            desftype = desfield.Type
            desflength = desfield.Length
            break
        else:
            pass
        desfield = desfields.Next()
    if desftype == "String":
        desntype = "Text"
        desnlength = desflength
    elif desftype == "Integer":
        desntype = "Long"
    elif desftype == "SmallInteger":
        desntype = "Short"
    else:
        gp.AddError("Destination Key field type is not a string, integer, or small integer. (Exiting Script).")
        sys.exit()
except:
    gp.AddWarning(gp.getmessages())
    gp.AddError("Problem encountered identifying the origin-destination key fields type and length. (Exiting Script)")
    sys.exit()
#
#Build origin coordinate-key list from origin feature class
#
def org_lists(orgFC):
    if orgExp != "#":
        in_Layer = "in_Layer"
        org_Layer = "org_Layer"
        gp.MakeFeatureLayer_management(orgFC, in_Layer, "", "", "")
        gp.SelectLayerByAttribute_management(in_Layer, "NEW_SELECTION", orgExp)
        gp.MakeFeatureLayer_management(in_Layer, org_Layer, "", "", "")
        rows = gp.SearchCursor(org_Layer)
        row = rows.next()
        orgxy = []
        orgkeylist = []
        try:
            while row:
                ashape = row.shape
                pnt = ashape.GetPart()
                pntx = pnt.x
                pnty = pnt.y
                if str(pntx) == "1.#QNAN" or str(pnty) == "1.#QNAN":
                    pass
                else:
                    orgkeyid = row.GetValue(orgkey)
                    orgkeylist.append(orgkeyid)
                    orgxy.append(float(pntx))
                    orgxy.append(float(pnty))
                row = rows.next()
            del rows
            del row
            if len(orgxy) == 0:
                gp.AddError("Valid origin values could not be identified. This may be because records were selected \
with 'Not a Number' coordinate values. Common for 'unmatched records' in a geocoded address database.  (Exiting Script)")
                sys.exit()
            else:
                pass
            gp.AddMessage("Origin coordinates and key values added to origin list.")
            
            return (orgxy, orgkeylist)
        except:
            gp.AddWarning(gp.getmessages())
            gp.AddError("Problem encountered creating origin coordinate-key list. (Exiting script)")
            del rows
            del row
            sys.exit() 
    else:
        rows = gp.SearchCursor(orgFC)
        row = rows.next()
        orgxy = []
        orgkeylist = []
        try:
            while row:
                ashape = row.shape
                pnt = ashape.GetPart()
                pntx = pnt.x
                pnty = pnt.y
                if str(pntx) == "1.#QNAN" or str(pnty) == "1.#QNAN":
                    pass
                else:
                    orgkeyid = row.GetValue(orgkey)
                    orgkeylist.append(orgkeyid)
                    orgxy.append(float(pntx))
                    orgxy.append(float(pnty))
                row = rows.next()
            del rows
            del row
            if len(orgxy) == 0:
                gp.AddError("Valid origin values could not be identified. This may be because records were selected \
with 'Not a Number' coordinate values. Common for 'unmatched records' in a geocoded address database.  (Exiting Script)")
                sys.exit()
            else:
                pass            
            gp.AddMessage("Origin coordinates and key values added to origin list.")
            return (orgxy, orgkeylist)
        except:
            gp.AddWarning(gp.getmessages())
            gp.AddError("Problem encountered creating origin coordinate-key list. (Exiting script)")
            del rows
            del row
            sys.exit()
#
#Build destination coordinate-key list from destination feature class
#
def des_lists(desFC):
    if desExp != "#":
        in_Layer2 = "in_Layer2"
        des_Layer = "des_Layer"
        gp.MakeFeatureLayer_management(desFC, in_Layer2, "", "", "")
        gp.SelectLayerByAttribute_management(in_Layer2, "NEW_SELECTION", desExp)
        gp.MakeFeatureLayer_management(in_Layer2, des_Layer, "", "", "")
        rows = gp.SearchCursor(des_Layer)
        row = rows.next()
        desxy = []
        deskeylist = []
        try:
            while row:
                ashape = row.shape
                pnt = ashape.GetPart()
                pntx = pnt.x
                pnty = pnt.y
                if str(pntx) == "1.#QNAN" or str(pnty) == "1.#QNAN":
                    pass
                else:
                    deskeyid = row.GetValue(deskey)
                    deskeylist.append(deskeyid)
                    desxy.append(float(pntx))
                    desxy.append(float(pnty))
                row = rows.next()
            del rows
            del row
            if len(desxy) == 0:
                gp.AddError("Valid destination values could not be identified. This may be because records were selected \
with 'Not a Number' coordinate values. Common for 'unmatched records' in a geocoded address database.  (Exiting Script)")
                sys.exit()
            else:
                pass            
            gp.AddMessage("Destination coordinates and key values added to destination list.")
            return (desxy, deskeylist)
        except:
            gp.AddWarning(gp.getmessages())
            gp.AddError("Problem encountered creating destination coordinate-key list. (Exiting script)")
            del rows
            del row
            sys.exit() 
    else:
        rows = gp.SearchCursor(desFC)
        row = rows.next()
        desxy = []
        deskeylist = []
        try:
            while row:
                ashape = row.shape
                pnt = ashape.GetPart()
                pntx = pnt.x
                pnty = pnt.y
                if str(pntx) == "1.#QNAN" or str(pnty) == "1.#QNAN":
                    pass
                else:
                    deskeyid = row.GetValue(deskey)
                    deskeylist.append(deskeyid)
                    desxy.append(float(pntx))
                    desxy.append(float(pnty))
                row = rows.next()
            del rows
            del row
            if len(desxy) == 0:
                gp.AddError("Valid destination values could not be identified. This may be because records were selected \
with 'Not a Number' coordinate values. Common for 'unmatched records' in a geocoded address database.  (Exiting Script)")
                sys.exit()
            else:
                pass            
            gp.AddMessage("Destination coordinates and key values added to destination list.")
            return (desxy, deskeylist)
        except:
            gp.AddWarning(gp.getmessages())
            gp.AddError("Problem encountered creating destination coordinate-key list. (Exiting script)")
            del rows
            del row
            sys.exit() 
#
#Assign values returned by the org_lists and des_lists functions to list variables.
#
org_lists = org_lists(orgFC)
des_lists = des_lists(desFC)
#
#Create the polyline feature class and add 'ORG_ID', 'DES_ID' & 'DES_LENGTH' fields'.
#
try:
    gp.CreateFeatureClass(os.path.dirname(outFC),os.path.basename(outFC),"Polyline","#","#","#",orgsr)
    gp.AddMessage("Polyline feature class created successfully.")
    if orgntype == "text":
        gp.AddField(outFC, "ORG_ID", orgntype, "#", "#", orgnlength)
    else:
        gp.AddField(outFC, "ORG_ID", orgntype, "#", "#", "#", "#", "#", "#", "#")
    if desntype == "text":
        gp.AddField(outFC, "DES_ID", desntype, "#", "#", desnlength)
    else:
        gp.AddField(outFC, "DES_ID", desntype, "#", "#", "#", "#", "#", "#", "#")
    gp.AddField(outFC, "DES_LENGTH", "DOUBLE", "18", "6", "#", "#", "#", "#", "#")
    gp.AddMessage("Added 'ORG_ID', 'DES_ID' & 'DES_LENGTH' Fields to the table.")
except:
    gp.AddWarning(gp.getmessages())
    gp.AddError("Problem encountered creating feature class. (Exiting script)")
    sys.exit()
#
#Construct polyline features
#
orgxy = org_lists[0]
orgkeylist = org_lists[1]
orglen = len(orgxy)
desxy = des_lists[0]
deskeylist = des_lists[1]
deslen = len(desxy)
gp.AddMessage("Beginning Polyline Construction...")
cur = gp.InsertCursor(outFC)
lineArray = gp.CreateObject("Array")
pnt = gp.CreateObject("Point")
dinc = 0
oinc = 0
odlist = []
okey = 0
dkey = 0
try:
    while oinc < orglen:
        orgx = oinc
        orgy = oinc + 1
        dinc = 0
        dkey = 0
        while dinc < deslen:
            desx = dinc
            desy = dinc + 1
            deltaxy = math.sqrt((desxy[desx]-orgxy[orgx])**2 + (desxy[desy]-orgxy[orgy])**2)
            if deltaxy == 0:
                dinc = dinc + 2
                dkey = dkey + 1              
            else:
                odlist.append(orgkeylist[okey])
                odlist.append(deskeylist[dkey])
                pnt.x = orgxy[orgx]
                pnt.y = orgxy[orgy]
                lineArray.add(pnt)
                pnt.x = desxy[desx]
                pnt.y = desxy[desy]
                lineArray.add(pnt)
                feat = cur.NewRow()
                feat.shape = lineArray
                cur.InsertRow(feat)
                lineArray.RemoveAll()
                dinc = dinc + 2
                dkey = dkey + 1
        oinc = oinc + 2
        okey = okey + 1
    del cur
except:
    gp.AddWarning(gp.getmessages())
    gp.AddError("Unable to construct polyline. (Exiting Script)")
    del cur
    sys.exit()
#
#Populate 'ORG_ID', 'DES_ID' & 'DES_LENGTH' fields with values.
#
rows = gp.UpdateCursor(outFC)
row = rows.next()
gp.AddMessage("Updating 'ORG_ID', 'DES_ID' & 'DES_LENGTH' Fields...")
ikey = 0
try:
    while row:
        dfeat = row.shape
        dlength = dfeat.Length
        oval = odlist[ikey]
        dval = odlist[ikey + 1]
        row.SetValue("ORG_ID", oval)
        row.SetValue("DES_ID", dval)
        row.SetValue("DES_LENGTH", dlength)
        rows.UpdateRow(row)
        ikey = ikey + 2
        row = rows.next()
    del rows
    del row
    gp.AddMessage("Completed update of 'ORG_ID', 'DES_ID' & 'DES_LENGTH fields.")
except:
    gp.AddWarning(gp.getmessages())
    gp.AddError("Encountered a problem updating 'ORG_ID', 'DES_ID' & 'DES_LENGTH' fields. (Exiting Script)")
    del rows
    del row
    sys.exit()
#
del gp
            
            