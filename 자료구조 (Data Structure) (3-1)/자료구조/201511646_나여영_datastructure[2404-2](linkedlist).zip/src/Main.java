
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList linkedList = new LinkedList();
		linkedList.addLast("A");
		linkedList.addLast("B");
		linkedList.addLast("C");
		linkedList.addLast("D");
		linkedList.addLast("E");
		linkedList.addLast("F");
		linkedList.addLast("G");
		linkedList.addLast("H");
		linkedList.addLast("I");
		linkedList.printAllNodes();

	}

}
