import java.util.Stack;
public class StackTest {
	static Stack s = new Stack();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		push_method(3);
		push_method(5);
		pop_method();
		pop_method();
		pop_method();
		pop_method();
		push_method(6);
		push_method(8);
		System.out.println("���� ������ ����ֽ��ϱ�? "+s.isEmpty());
		pop_method();
		top_method();
		pop_method();
		System.out.println("���� ������ ����ֽ��ϱ�? "+s.isEmpty());

	}
	static void show(int output){
		if (output==-1)
			System.out.print("Output: - Stack : ");
		else if (output ==0)
			System.out.print("Error");
		else 
			System.out.print("Output: " + output + " Stack : ");
		for (int i =0; i<s.size(); i++){
			System.out.print(s.get(i) + " ");
		}
		System.out.println();
	}
	static void push_method(int i){

		s.push(i);
		show(-1);
	}
	static void pop_method(){
		int output=0;
		if (!s.isEmpty())
			output = (int)s.pop();
		else
			output=0;
		show(output);
	}
	static void top_method(){
		int output=0;
		if (!s.isEmpty())
			output = (int)s.peek();
		else
			output=0;
		show(output);
	
	}
}
