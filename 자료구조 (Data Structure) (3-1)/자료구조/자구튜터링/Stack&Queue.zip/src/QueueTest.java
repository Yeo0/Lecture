import java.util.LinkedList;
import java.util.Queue;

public class QueueTest {
	static Queue q = new LinkedList();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		enqueue_method(5);
		enqueue_method(3);
		dequeue_method();
		enqueue_method(8);
		dequeue_method();
		System.out.println("���� ť�� ����ֽ��ϱ�? " + q.isEmpty());
		front_method();
		dequeue_method();	
		System.out.println("���� ť�� ����ֽ��ϱ�? " + q.isEmpty());

		dequeue_method();
		
	}
	static void show(int output){
		if (output==-1)
			System.out.print("Output: - Front : " + q.peek());
		else if (output ==0)
			System.out.print("Error");
		else 
			if (!q.isEmpty()){
				System.out.print("Output: " + output + " Front : " + q.peek());
			} else{
				System.out.print("Output: " + output + " Front : -");
			}
					
		System.out.println();
	}
	static void enqueue_method(int i){

		q.offer(i);
		show(-1);
	}
	static void dequeue_method(){
		int output=0;
		if (!q.isEmpty())
			output = (int)q.poll();
		else
			output=0;
		show(output);
	}
	static void front_method(){
		int output=0;
		if (!q.isEmpty())
			output = (int)q.peek();
		else
			output=0;
		show(output);
	
	}
}
