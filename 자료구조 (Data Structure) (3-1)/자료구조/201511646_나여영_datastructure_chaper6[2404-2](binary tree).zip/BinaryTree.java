package binerytree;

public class BinaryTree  {
	
	TreeNode root;
	
	public BinaryTree (TreeNode root){
		this.root = root;		
	}
	
	public TreeNode left(TreeNode v){
		return v.getLeft();
	}
	
	public TreeNode right(TreeNode v){
		return v.getRight();
	}
	
	public boolean hasLeft(TreeNode v){
		if(v.getLeft()!=null){
			return true;
		}else{
		return false;
		}
	}
		

	public boolean hasRight(TreeNode v){
		if(v.getRight()!=null){
			return true;
		}else{
		return false; 
		}
	}
	
	public TreeNode insertLeft(TreeNode v, String data){
		
		if(v.getLeft()!=null){
			v=v.setLeft(data); //�𸣰ڴ�
			return v;
		}else return null;
		
		
	}
	
	public TreeNode insertRight(TreeNode v, String data){
		if(v.getRight()!=null){
			v=v.setRight(data);
			return v;
		}else return null;
			
	
		
	}
	

public TreeNode insert(TreeNode v, String data){
    if(v==null){
        v = new TreeNode(null, data);
    }else{
        v=v.setLeft(TreeNode(data.getLeft(), data));
     

    return v;
}

    //public TreeNode depth, insert, hasleft right, remove
    		
    	
    
    	
    }
    
	public Object remove(TreeNode v){
		
		
		
	}
	
	public void inOrder(TreeNode v){
		
		
		
	}
	
	
}




