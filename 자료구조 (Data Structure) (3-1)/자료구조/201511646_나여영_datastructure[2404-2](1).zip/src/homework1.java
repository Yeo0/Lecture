
public class homework1 {


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int count=0;
		String str = "my mom loves me!";
	
	    for(int i=0;i<=15;i++){
			if(str.charAt(i)=='m'){
				return count+1;
			}
		}
		
	}


}

