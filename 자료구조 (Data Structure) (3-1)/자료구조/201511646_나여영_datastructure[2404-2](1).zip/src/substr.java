
public class substr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String str = "my mom loves me!";
	
		
		System.out.println(str.substring(0,3));
	}

}
