
public class binerytest {

	public static int BinarySum(int[] arr, int i, int n){
				if (n==1){
					return arr[i];
				}
				else {
					return BinarySum(arr,i,n/2)+BinarySum(arr, i+n/2, n/2);
				}
			}
	public static void main(String[] args) {
			// TODO Auto-generated method stub
			int[] array = {1,2,3,4,5,6,7,8};
			System.out.println(BinarySum(array,0,8));
	}

}


	

