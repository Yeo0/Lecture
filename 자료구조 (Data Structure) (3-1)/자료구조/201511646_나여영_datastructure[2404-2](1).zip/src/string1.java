
public class string1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String msg = "Hello Smart Computing Laboratory";
		String word = "datastructure";
		
		System.out.println("Character at index 1 is"+ msg.charAt(1));
		System.out.println("Length of msg is"+ msg.length());
		if(word.equals("datastructure")){
			System.out.println("String word is same with\"datastructure\"");
		}
		
		String subMsg = msg.substring(0,4);
		
		System.out.println("Substring of msg is " + subMsg);
		
		int num = 10;
		String strNum = String.valueOf(num);
		
		System.out.println("Value \"num\" is Integer");
		System.out.println("Value \"strNum\" is String");
		
		
		System.out.println("Length of strNum is" + strNum.length());
		
		
	}

}
