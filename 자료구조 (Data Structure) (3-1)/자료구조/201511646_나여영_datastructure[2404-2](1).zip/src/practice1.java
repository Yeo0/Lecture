
public class practice1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "my mom loves me!";
		System.out.println(StringCounter(str, 0));
	}
	public static int StringCounter(String s,int i) {  
		
		if (i==s.length()-1){ 
			if (s.charAt(i)=='m'){    
				return 1;
			}
			else return 0;
		
		}
		else {
			if (s.charAt (i)=='m'){
				return 1 + StringCounter(s,i+1);

			}
			else return 0 + StringCounter(s,i+1);
		}
	}


}
