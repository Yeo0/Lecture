				
public class homework2 {

	String str = "my mom loves me!";
	
	public static int Binarytest(String[] arr, int i,int n){
		if (n==1){
			return arr[i];
		}
		else {
			return Binarytest(arr,i,n/2)+Binarytest(arr, i+n/2, n/2);
		}
	}
	
public static int StringCounter(String s,int i) {  
		
		if (i==s.length()-1){ 
			if (s.charAt(i)=='m'){    
				return 1;
			}
			else return 0;
		
		}
		else {
			if (s.charAt (i)=='m'){
				return 1 + StringCounter(s,i+1);

			}
			else return 0 + StringCounter(s,i+1);
		}
public static void main(String[] args) {
	// TODO Auto-generated method stub
	
	char[] c= null;
	c=str.toCharArray();
	

	System.out.println(Binarytest(c,0,16));


	System.out.println(StringCounter(str, 0));
	}

}


public static int StringCounter(String s,int i) {  
	
	if (i==s.length()-1){ 
		if (s.charAt(i)=='m'){    
			return 1;
		}
		else return 0;
	
	}
	else {
		if (s.charAt (i)=='m'){
			return 1 + StringCounter(s,i+1);

		}
		else return 0 + StringCounter(s,i+1);
	}
}