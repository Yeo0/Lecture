
package homework3;

import java.util.Stack;



public class Hw3 {
	static int size=0;
	
	public static void move(int n, Stack <Object>from, Stack <Object>by, Stack <Object>to){
		if(n==1) {
			Object a=from.pop();
			to.push(a);
	}else{
		move(n-1,from,to,by); 
		Object a=from.pop();
		to.push(a);
		move(n-1,by,from,to);
		
	}
	size=size+1;
	
	}
}

//���ڷ� �� �Ѱ��ٲ���