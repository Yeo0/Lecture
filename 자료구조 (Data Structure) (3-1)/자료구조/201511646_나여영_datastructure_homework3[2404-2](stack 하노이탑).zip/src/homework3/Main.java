
package homework3;

import java.util.Stack;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Number of disk :");
		Scanner scan = new Scanner(System.in);
		
	
		Stack <Object>s1 = new Stack<Object>();
		Stack <Object>s2 = new Stack<Object>();
		Stack <Object>s3 = new Stack<Object>();
		
		
		
		s1.push("C");
		s1.push("B");
		s1.push("A");
		Hw3.move(3,s1,s2,s3);
		
		System.out.println("Stack 1 :" + s1.pop());
		System.out.println("Stack 2 :" + s2.pop());
		
		for(int i=1; i<=3; i++){
		System.out.println();
			System.out.println("Stack 3 :" +s3.pop());
		}
		
			System.out.println("Number of movement :"+Hw3.size);
		
//syso ctrl spaceb System.out.println();

		
		
		
	}

}


