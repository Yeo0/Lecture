import java.util.Scanner;

public class FactorialTest {

	public static int recursiveFactorial(int n) {
		if(n==0) return 1;
		else return n*recursiveFactorial(n-1);

}
	public static void main(String[] args) {
		/*int value = recursiveFactorial(5);
		System.out.println(value);*/
		
		Scanner scan = new Scanner(System.in);
		System.out.print("n���� �Է��ϼ��� : ");
		int n = scan.nextInt();
		int value = recursiveFactorial(n);
		System.out.println(n+"!�� ���� "+ value + "�Դϴ�.");

	}

}

