package datastructure_tree;
import java.util.List;

public class Tree {
	
	private static TreeNode root;
	
	public Tree(TreeNode root){
		this.root=root;
	}
	
	public TreeNode root(){
		return this.root;
	}
	public TreeNode parent(TreeNode v){
		return v.getParent();
	}
	public List<TreeNode> children(TreeNode v){
		return v.getChild_list();
	}
	public boolean isInternal(TreeNode v){
		if(v.getChild_list().isEmpty())
			return true;
		else
			return false;
	}
	public boolean isRoot(TreeNode v){
		if(v.getParent()==null)
			return true;
		else return false;	
	}
	public void addChild (TreeNode p, String data){
		TreeNode newNode = new TreeNode (p, data);
		p.getChild_list().add(newNode);
	}
//	
//	public void preOrder(TreeNode n){
//		System.out.println(n.getData());
//		while(n.getChild_list()!=null) 
//			preOrder(v);


	
	public static int depth (Tree t, TreeNode n){
		if(t.isRoot(n)) return 0;
		else return 1+depth(t, t.parent(n));
	}
	
	public static int height(Tree t, TreeNode n){
		if(t.isRoot(n)) return 0;
		else if (n.getChild_list() == null) return 1;
		else{
			int h=0;
		for(TreeNode w : n.getChild_list()){
			h=Math.max(h,height(t,w));
		}
		return 1+h;
	}
 }
	
	     

	}
	
	
	
	
