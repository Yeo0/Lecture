package datastructure_tree;
import java.util.List;
import java.util.ArrayList;
public class TreeNode {

	private String data;
	private TreeNode parent;
	private List<TreeNode> Child_list;

	public TreeNode(){
		this.data= null;
		this.parent=null;
		this.Child_list= new ArrayList<TreeNode>();
	}
	public TreeNode(TreeNode parent, String data){
		this.data=data;
		this.parent=parent;
		this.Child_list=new ArrayList<TreeNode>();
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public TreeNode getParent() {
		return parent;
	}
	public void setParent(TreeNode parent) {
		this.parent = parent;
	}
	public List<TreeNode> getChild_list() {
		return Child_list;
	}
	public void setChild_list(List<TreeNode> child_list) {
		Child_list = child_list;
	}
	
	
	
	
}
