package datastructure2;

import java.util.Queue;
import java.util.LinkedList;

public class queue {
	static Queue q = new LinkedList();


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		q.offer(5);
		q.offer(3);
		int a=(int)q.poll();
		System.out.println(a);
		q.offer(7);
		q.poll();
		q.peek();
		q.poll();
		System.out.println(q.poll());
		System.out.println(q.isEmpty());
	}

}
