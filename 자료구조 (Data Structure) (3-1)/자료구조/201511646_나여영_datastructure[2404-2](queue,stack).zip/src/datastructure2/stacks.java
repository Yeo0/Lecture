package datastructure2;

import java.util.Stack;
import java.util.EmptyStackException;

public class stacks {

	static Stack s = new Stack();

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	s.push(5); 
	s.push(3);
	int a=(int) s.pop();
	System.out.println("Output :" + a + "stack");
	s.push(7);
	s.pop();
	s.peek();
	s.pop();
	try{
	s.pop();
	}catch (EmptyStackException e){
		System.out.println("error");
	}
	s.isEmpty();
			
		
	}

}
