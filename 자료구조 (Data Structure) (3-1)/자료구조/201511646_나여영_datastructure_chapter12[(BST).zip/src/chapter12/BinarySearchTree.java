package chapter12;

public class BinarySearchTree {

	public static Node root;
	public BinarySearchTree(){
		this.root=null;
	}
	
	public Node TreeSearch (int k, Node v){
		if(v==null) return v;
		if(k<v.getData()) return TreeSearch(k, v.getLeft());
		else if (k>v.getData()) return TreeSearch(k,v.getRight());
		
		return v;
	}
	
	public boolean find (int id){
		Node search=TreeSearch(id,root);
		if(search==null)
			return false;
		else return true;
		
	}
	//���迡�� ã�Ƽ� ã�� ��带 �����ض� -> �ϸ� treesearch �������� ��
	
	
	public void insert (int value){
		if(root==null){
			Node newNode = new Node(value);
			root = newNode;
		}
		else insertRecursive(value, root);
	}
	
	public Node insertRecursive(int value, Node node){
		
		if(node==null){
			Node newNode= new Node(value);
			return newNode;
		}
		else if (value<node.getData()){
			Node ret=insertRecursive(value, node.getLeft());
			node.setLeft(ret);
			return node;
		}
		else if(value>node.getData()){
			Node ret= insertRecursive (value, node.getRight()); 
			node.setRight(ret); //�������ϴ� �۾�. �� �ʿ���
			return node;
		}
		else return node;
		
		}

	public boolean delete(int value){
		Node parent = root;
		Node current = root; 
		boolean isLeftChild= false;
		while(current.getData()!=value){
			parent=current;
			if(current.getData()>value){
				isLeftChild=true;
				current = current.getLeft();
			}else{
				isLeftChild=false;
				current=current.getRight();
			}
			if(current==null){
				return false;
				}
			}

	
	if(current.getLeft()==null && current.getRight()==null){
		if(current==root){
			root=null;
			//current =null; �ؤ�����
		}
		if(isLeftChild==true){
			parent.setLeft(null);
		}else{
			parent.setRight(null);
		}
	}
	
	else if(current.getRight()==null){
		if(current==root){
			root=current.getLeft();
		}else if(isLeftChild){
			parent.setLeft(current.getLeft());
		}else{
			parent.setRight(current.getLeft());
		}
	}
	else if (current.getLeft()==null){
		if(current==root)
	}
	else if (current.getLeft()!=null&&current.getRight()!=null){
		Node successor = getSuccessor(current);
	}
	return true;
}
	public Node getSuccessor(Node deleleNode){
		Node successsor=null;
		Node successsorParent=null;
		Node current=deleleNode.right;
		while(current!=null){
		}
		if(successsor!=deleleNode.right){
			successsorParent.left=successsor.right;
			successsor.right=deleleNode.right;
		}
		return successsor;
	}
	public void displayInorder(Node root){
		
	}
}
	
	
	
	


