package datastructure_map;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map map = new Map();
		
	}

}
