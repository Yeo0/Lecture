package midterm_review;

public class List2 {

		private ListNode2 header;
		private ListNode2 trailer;
		
		public List2(){
			header = new ListNode2();
			trailer = new ListNode2();
			header.setNextNode(trailer);
			trailer.setPrevNode(header);
		}
		
		public ListNode2 getHeader(){
			return header;
		}

		public void setHeader(ListNode2 header){
			this.header = header;
		}
		public ListNode2 getTrailer(){
			return trailer;
		}
		public void setTrailer(ListNode2 trailer){
			this.trailer = trailer;
		}
		public void initialization(){
			header.setNextNode(trailer);
			trailer.setPrevNode(header);
		}
		
		public void addLast (TreeNode2 command){
			ListNode2 newNode = new ListNode2(trailer.getPrevNode(),trailer, command);
			trailer.getPrevNode().setNextNode(newNode);
			trailer.setPrevNode(newNode);
		}
		
		public ListNode2 getNode(int i){
			ListNode2 temp=header.getNextNode();
			for (int c=0;c<i;c++){
				temp=temp.getNextNode();
			}
			return temp;
		}
		
		
	}



