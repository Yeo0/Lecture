package midterm_review;

public class TreeNode {
	
	private String data;
	private TreeNode left;
	private TreeNode right;
	private TreeNode parent;
	
	public TreeNode(String data, TreeNode parent){
		this.parent = parent;
		this.data=data;
		this.left=null;
		this.right=null;
	}
	public String getData(){
		return data;
		
	}
	public void setData(String data){
		this.data=data;
	}
	public TreeNode getLeft(){
		return left;
	}
	public void setLeft(TreeNode left){
		this.left = left;
	}
	public TreeNode getRight(){
		return right;
	}
	public void setRight(TreeNode right){
		this.right=right;
	}
	public TreeNode getParent(){
		return parent;
	}
	public void setParent (TreeNode parent){
		this.parent=parent;
	}
	
}
