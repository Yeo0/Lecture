package midterm_review;



public class TreeNode2 {

	private ListNode2 data;
	private TreeNode2 parent;
	
	
	
	public TreeNode2(ListNode2 data, TreeNode2 parent){
		this.parent = parent;
		this.data=data;
	}
	

	
	public ListNode2 getData(){
		return data;
		
	}
	public void setData(ListNode2 data){
		this.data=data;
	}
	public TreeNode2 getParent(){
		return parent;
	}
	public void setParent (TreeNode2 parent){
		this.parent=parent;
	}
	

}
