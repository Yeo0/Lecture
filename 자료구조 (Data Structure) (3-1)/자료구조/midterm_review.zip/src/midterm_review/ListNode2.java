package midterm_review;

public class ListNode2 {

	private TreeNode2 command;
	private ListNode2 nextNode;
	private ListNode2 prevNode;
	
	public ListNode2(){
		this.prevNode = null;
		this.nextNode = null;
		this.command = null;
	}
	public ListNode2 (ListNode2 prevNode, ListNode2 nextNode, TreeNode2 command){
		this.prevNode=prevNode;
		this.nextNode=nextNode;
		this.command=command;
	}
	public TreeNode2 getCommand(){
		return command;
	}
	public void setCommand(TreeNode2 command){
		this.command = command;
	}
	public ListNode2 getNextNode(){
		return nextNode;
	}
	public void setNextNode(ListNode2 nextNode){
		this.nextNode = nextNode;
	}
	public ListNode2 getPrevNode(){
		return prevNode;
	}
	public void setPrevNode (ListNode2 prevNode){
		this.prevNode=prevNode;
	}
	

}
