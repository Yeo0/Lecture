package chapter11;

//import java.util.LinkedList;
import java.util.List;

public class Dictionary {

	private DictionaryNode header;
	private DictionaryNode trailer;
	
	public Dictionary(){
		header = new DictionaryNode(null, this.trailer, null, null); // �ڵ岿�� �������� this 
		trailer = new DictionaryNode(this.header, null, null, null);
	}
	
	public void insert( String key, String value){
		DictionaryNode newNode = new DictionaryNode(this.trailer.getPrev(), this.trailer, key,value);
		this.trailer.getPrev().setNext(newNode);
		this.trailer.setPrev(newNode);
	}
	
	public String find(String key){
		DictionaryNode temp = header.getNext();
		String rtValue="";
		boolean findOK = false;
		
		while(temp!=trailer){ //trialer �ɶ�����
			
			//first key return
			if(key.equals(temp.getKey())){
				rtValue= temp.getValue();
				findOK=true;
				break;
			}
			temp=temp.getNext();
		}
		if(findOK==false){
			System.out.println("NOT FOUND!");
		}
		
		return rtValue; //������ �ȵǴ¾ֵ������� null���� �����
	}
	
	public void findAll(String key){ //������ list�� ����
		DictionaryNode temp = header.getNext();
		String rtValue="";
		boolean findOK=false;
		
		while(temp!=trailer){ //trialer �� �ƴҶ����� while �� ����
			//record all value
			if(key.equals(temp.getKey())){
				rtValue +="[";
				rtValue +="temp.getValue()";
				rtValue +="]";
				findOK=true;
						}	
		temp=temp.getNext();	
		}
		if(findOK==false){
		System.out.println("NOT FOUND!");
		}
		System.out.println(rtValue);
	
	}
	
	public void remove (String key){
		DictionaryNode temp = header.getNext();
	//	List<DictionaryNode> list = new LinkedList(); // 
		while(temp!=trailer){ //trialer �� �ƴҶ����� while �� ����
			if(key.equals(temp.getKey())){ //int��  == ����
				temp.getPrev().setNext(temp.getNext());
				temp.getNext().setPrev(temp.getPrev());
		//		list.add(temp);
			}
			temp=temp.getNext();
		}
		//for(int i=0;i<list.size();i++){
		//	list.set(i,null); //�� ��� �ϸ� �ɱ�
		}
	}
	

	
	


