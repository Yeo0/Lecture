package chapter11;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Dictionary dic= new Dictionary();
		
		dic.insert("apple", "sweet");
		dic.insert("bananas", "sweet");
		dic.insert("apple", "fresh");
		dic.insert("bear","pretty");
		dic.insert("bear", "smart");
		
	
		System.out.println(dic.find("bear"));
		
		dic.findAll("apple");
		
		dic.findAll("bear");;
		
	}

}

