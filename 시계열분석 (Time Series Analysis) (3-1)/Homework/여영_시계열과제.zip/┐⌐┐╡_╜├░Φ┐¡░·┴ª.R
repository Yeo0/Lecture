rm(list = ls()); gc(reset = T)

# install.packages("forecast");
library(forecast);

train = read.csv("C:\\Users\\kkk1\\Desktop\\안면도온실가스.csv", header = T)
test = read.csv("C:\\Users\\kkk1\\Desktop\\안면도 온실가스 2014년.csv", header = T)

#original data ploting
ts.train = ts(train,freq=12,start=1999)
str(ts.train)
plot(ts.train[,2], main="안면도 CO2", ylab="CO2");

#1th differences data ploting
df.ts.train = diff(ts.train[,2], differences = 1)
plot(df.ts.train, main="안면도 CO2(1차 차분)", ylab="dif_CO2")

#seasonal differences data ploting
sdf.ts.train = diff(ts.train[,2], lag = 12, differences = 1)
plot(sdf.ts.train, main="안면도 CO2(계절 차분)", ylab="s.dif_CO2")

par(mfrow = c(1, 2))

acf(sdf.ts.train)
pacf(sdf.ts.train)

par(mfrow = c(1, 1))

#seasonal + 1th differences data ploting
s.df.ts.train = diff(df.ts.train, lag = 12, differences = 1)
plot(s.df.ts.train, main = "안면도 CO2(계절 + 1차 차분)", ylab = "s.d.dif_co2")

par(mfrow = c(1, 2))
acf(s.df.ts.train)
pacf(s.df.ts.train)

par(mfrow = c(1, 1))

auto.arima(ts.train[, 2])

fit1 = arima(ts.train[, 2], order = c(3, 0, 2), seasonal = list(order = c(2, 1, 0)));fit1
fit2 = arima(ts.train[, 2], order = c(3, 0, 1), seasonal = list(order = c(2, 1, 0)));fit2
fit3 = arima(ts.train[, 2], order = c(1, 0, 1), seasonal = list(order = c(1, 1, 1)));fit3
fit4 = arima(ts.train[, 2], order = c(4, 1, 2), seasonal = list(order = c(2, 1, 0)));fit4
fit5 = arima(ts.train[, 2], order = c(3, 1, 0), seasonal = list(order = c(2, 1, 0)));fit5
fit6 = arima(ts.train[, 2], order = c(3, 1, 1), seasonal = list(order = c(1, 1, 0)));fit6
fit7 = arima(ts.train[, 2], order = c(2, 1, 1), seasonal = list(order = c(1, 1, 1)));fit7 #얘가 베스트임(aic 기준)
fit8 = arima(ts.train[, 2], order = c(2, 1, 0), seasonal = list(order = c(1, 1, 1)));fit8

plot(forecast(fit7))
forecasting = as.data.frame(forecast.Arima(fit7, h=24))[-c(1:11), ]

result = c(mean(forecasting$`Point Forecast`), mean(test$이산화탄소..ppm.))
names(result) = c("2014년 예측평균", "2014년 원자료평균")
result




